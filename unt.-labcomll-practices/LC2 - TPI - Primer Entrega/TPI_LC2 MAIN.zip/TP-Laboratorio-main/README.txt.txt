TPI_LC2

Integrantes grupo:
Gutierrez Santino
Martinez Lorenzo
Pagano Keila

Aclaraciones:
El recuadro que figura al compartir informacion, consideramos no incluirlo debido a que planeamos diseñarlo con un responsive para que sea funcional en la segunda etapa.

